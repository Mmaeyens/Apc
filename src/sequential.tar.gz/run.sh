#! /bin/bash
./build/cars